package backend.thinthere.enums;

public enum Status {

    IN_BASKET,
    ORDERED,
    PICKED,
    AT_RUNNER,
    DELIVERED,
    STORNO
}
