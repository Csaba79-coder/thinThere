package backend.thinthere.enums;

public enum Category {

    SPORTS_EQUIPMENT,
    PROTEIN_POWDER,
    VITAMIN,
    PERFORMANCE_ENHANCING_SUPPLEMENT,
    WEIGH_CONTROLLING_FORMULA
}
