package backend.thinthere.enums;

public enum Goal {
    CARDIO,
    STRENGTHEN
}
