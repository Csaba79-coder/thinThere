package backend.thinthere.enums;

public enum TypeOfPayment {

    CASH,
    BANK_TRANSFER,
    DIRECT_DEBIT,
    BANKCARD,
}
