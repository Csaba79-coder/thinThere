package backend.thinthere.enums;

public enum Role {
  USER,
  ADMIN
}
