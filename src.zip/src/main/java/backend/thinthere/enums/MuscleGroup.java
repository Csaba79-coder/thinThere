package backend.thinthere.enums;

public enum MuscleGroup {

  ABDOMINAL_MUSCLE,
  PECTORAL_MUSCLE,
  BICEPS,
  TRICEPS,
  HUMERAL_MUSCLE,
  BACK_MUSCLE,
  CALF,
  GLUTEAL_AND_THIGH_MUSCLE,
  FOREARM,
  FULL_BODY

}
