package backend.thinthere;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ThinThereApplication {

	public static void main(String[] args) {
		SpringApplication.run(ThinThereApplication.class, args);
	}

}
